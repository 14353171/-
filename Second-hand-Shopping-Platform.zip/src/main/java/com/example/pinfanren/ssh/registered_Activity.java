package com.example.pinfanren.ssh;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.FragmentManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.test.suitebuilder.annotation.MediumTest;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class registered_Activity extends AppCompatActivity {
    private Button register,back, camera;
    private EditText register_username,register_password,register_password_again;
    login_information DB = new login_information(this);

    @SuppressLint("SdCardPath")
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registered);

        register = (Button) findViewById(R.id.register);
        back = (Button) findViewById(R.id.back);
        register_username = (EditText) findViewById(R.id.register_username_input);
        register_password = (EditText) findViewById(R.id.register_password_input);
        register_password_again = (EditText) findViewById(R.id.register_password_input_again);
        final SharedPreferences sp = this.getSharedPreferences("MY_PREFERENCE", MODE_PRIVATE);
        final SharedPreferences.Editor editor = sp.edit();

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor query = DB.query_information();
                int i = 0;
                while (query.moveToNext()) {
                    int num = query.getColumnIndex("username");
                    final String save_name = query.getString(num);
                    if (register_username.getText().toString().equals(save_name)) {
                        i++;
                    }
                }
                if (register_username.getText().toString().equals("") ||
                        register_password.getText().toString().equals("") ||
                        register_password_again.getText().toString().equals("")) {
                    Toast.makeText(registered_Activity.this, "上述信息皆不能为空，请检查！", Toast.LENGTH_SHORT).show();
                }
                else if (i > 0) {
                    Toast.makeText(registered_Activity.this, "该用户已被注册，请修改！", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (!register_password.getText().toString().equals(register_password_again.getText().toString())) {
                        Toast.makeText(registered_Activity.this, "确认密码与登录密码不一致，请检查！", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Intent intent = new Intent(registered_Activity.this,Log_in_Activity.class);
                        startActivity(intent);

                        editor.putString("password",register_password.getText().toString());
                        editor.commit();
                        DB.insert_information(register_username.getText().toString(), register_password.getText().toString());
                    }
                }
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(registered_Activity.this,Log_in_Activity.class);
                startActivity(intent1);
            }
        });

        camera = (Button) findViewById(R.id.camera);
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction("android.media.action.IMAGE_CAPTURE");
                intent.addCategory("android.intent.category.DEFAULT");
                startActivityForResult(intent,1);
            }
        });

    }

    @SuppressLint("SdCardPath")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode == Activity.RESULT_OK) {
            String sdStatus = Environment.getExternalStorageState();
            //检测SD卡是否可用
            if(!sdStatus.equals(Environment.MEDIA_MOUNTED)){
                Log.i("TestFile","SD card is not available right now");
                return;
            }
            Bundle bundle = data.getExtras();
            Bitmap bitmap = (Bitmap) bundle.get("data");//获取相机返回的数据，并转换为Bitmap图片格式
            Drawable drawable =new BitmapDrawable(bitmap);

            FileOutputStream b = null;
            File file = new File("/sdcard/Image/");
            file.mkdirs();//创建文件夹
            String fileName = "/sdcard/Image/666p.jpg" ;

            camera.setBackgroundDrawable(drawable);

            try {
                b = new FileOutputStream(fileName);
                bitmap.compress(Bitmap.CompressFormat.JPEG,100,b);//把数据写入
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } finally {
                try {
                    b.flush();
                    b.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}