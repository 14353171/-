package com.example.pinfanren.ssh;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ClassAdapter extends RecyclerView.Adapter<ClassAdapter.ViewHolder> implements View.OnClickListener{
    private ArrayList<Integer> class_list;
    private LayoutInflater mInflater;
    private Context c;
    private String[]class_name={"衣服","箱包","书籍","电子产品","全部"};

    public interface OnItemClickListener {
        void onItemClick(View view, int position);
    }
    private OnItemClickListener mOnItemClickListener;
    public void setOnItemClickListener(OnItemClickListener mOnItemClickListener) {
        this.mOnItemClickListener = mOnItemClickListener;
    }
    public ClassAdapter(Context context, ArrayList<Integer> items) {
        super();
        c=context;
        class_list = items;
        mInflater = LayoutInflater.from(context);
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = mInflater.inflate(R.layout.class_item, viewGroup, false);
        ViewHolder holder = new ViewHolder(view);
        holder.first=(ImageView)view.findViewById(R.id.clothes);
        holder.text=(TextView)view.findViewById(R.id.class_name);
        view.setOnClickListener(this);
        return holder;
    }
    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int i) {
        int fi =  class_list.get(i);
        Drawable drawable1= c.getResources().getDrawable(fi);
        viewHolder.first.setBackground(drawable1);
        viewHolder.text.setText(class_name[i]);
        viewHolder.itemView.setTag(i);

    }
    public void onClick(View v) {
        if (mOnItemClickListener != null) {
            mOnItemClickListener.onItemClick(v,(int)v.getTag());
        }
    }
    @Override
    public int getItemCount() {
        return class_list.size();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder{
        public ViewHolder(View itemView) {
            super(itemView);
        }
        ImageView first;
        TextView text;
    }
}
