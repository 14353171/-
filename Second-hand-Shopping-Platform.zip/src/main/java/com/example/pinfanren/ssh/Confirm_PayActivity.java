package com.example.pinfanren.ssh;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Confirm_PayActivity extends AppCompatActivity {
    private Button confirm;
    private EditText recevier,phone,address,postal_code;
    private TextView product_name,product_detail,product_price;
    private ImageView product_picture;
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pay_confirm);

        confirm = (Button) findViewById(R.id.confirm);
        Button cancel = (Button) findViewById(R.id.cancel1);
        recevier = (EditText) findViewById(R.id.Receiver_input);
        phone = (EditText) findViewById(R.id.Phone_input);
        address = (EditText) findViewById(R.id.Address_input);
        postal_code = (EditText) findViewById(R.id.Postal_code_input);
        product_picture = (ImageView) findViewById(R.id.Product_picture);
        product_name = (TextView) findViewById(R.id.Product_name);
        product_detail = (TextView) findViewById(R.id.Product_detail);
        product_price = (TextView) findViewById(R.id.Product_price);
        final AlertDialog.Builder builder =  new AlertDialog.Builder(this);

        Bundle bundle = this.getIntent().getExtras();
        Intent intent = this.getIntent();
        product_name.setText(bundle.getString("product_name"));
        product_detail.setText(bundle.getString("product_detail"));
        product_price.setText(bundle.getString("product_price"));
        Bitmap bitmap = intent.getParcelableExtra("bitmap");
        product_picture.setImageBitmap(bitmap);

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.setTitle("支付详情").setMessage("是否确认支付？").
                        setPositiveButton("是", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent Static_intent = new Intent("STATICACTION");
                                Bundle bundle = new Bundle();
                                if (recevier.getText().toString().equals("") ||
                                        phone.getText().toString().equals("") ||
                                        address.getText().toString().equals("") ||
                                        postal_code.getText().toString().equals("")) {
                                    Toast.makeText(Confirm_PayActivity.this, "收货信息不能为空！", Toast.LENGTH_SHORT).show();
                                }
                                else {
                                    bundle.putString("name",recevier.getText().toString());
                                    bundle.putString("phone",phone.getText().toString());
                                    bundle.putString("address",address.getText().toString());
                                    bundle.putString("postcode",postal_code.getText().toString());
                                    bundle.putString("product_name",product_name.getText().toString());
                                    bundle.putString("product_detail",product_detail.getText().toString());
                                    bundle.putString("product_price",product_price.getText().toString());
                                    sendBroadcast(Static_intent);
                                    Intent intent1 = new Intent(Confirm_PayActivity.this,Pay_DetailActivity.class);
                                    intent1.putExtras(bundle);
                                    startActivity(intent1);
                                }
                            }
                        }).setNegativeButton("否", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //取消订单
                        Toast.makeText(Confirm_PayActivity.this,
                                "您已取消订单！", Toast.LENGTH_SHORT).show();
                    }
                }).create().show();
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转界面，代码
                Intent intent = new Intent();
                intent.setClass(Confirm_PayActivity.this,MainMenuActivity.class);
                startActivity(intent);
            }
        });
    }
}