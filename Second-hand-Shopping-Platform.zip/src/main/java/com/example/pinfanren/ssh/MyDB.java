package com.example.pinfanren.ssh;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by pinfanren on 2016/12/1.
 */

public class MyDB extends SQLiteOpenHelper {
    private static final String DB_NAME = "shopping.db";
    private static final String TABLE_NAME = "barn";
    private static final int DB_VERSION = 1;
    private String[]class_name={"clothes","bag","book","electronic","all"};
    private int [] img = {R.mipmap.cloth1,R.mipmap.cloth2,R.mipmap.cloth3,R.mipmap.cloth4,R.mipmap.cloth5,
            R.mipmap.cloth6,R.mipmap.cloth7,R.mipmap.cloth8
            ,R.mipmap.bag1,R.mipmap.bag2,R.mipmap.bag3,R.mipmap.bag4,R.mipmap.bag5,R.mipmap.bag6
            ,R.mipmap.book1,R.mipmap.book2,R.mipmap.book3,R.mipmap.book4,R.mipmap.book5,R.mipmap.book6,R.mipmap.book7,R.mipmap.book8
            ,R.mipmap.electronic1,R.mipmap.electronic2,R.mipmap.electronic3,R.mipmap.electronic4,
            R.mipmap.electronic5,R.mipmap.electronic6,R.mipmap.electronic7,R.mipmap.electronic8};
    private Context c;
    MyDB(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        c=context;
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase){
        String CREATE_TABLE = "create table if not exists "
                +TABLE_NAME
                +"(_id INTEGER PRIMARY KEY,class_name TEXT,image BLOB,product_name TEXT,price TEXT,shop int,detail TEXT)";
        sqLiteDatabase.execSQL(CREATE_TABLE);
        InputStream inputStream = MainMenuActivity.class.getClassLoader().getResourceAsStream("assets/person.xml");
        List<Person> persons;
        try {
            persons = PersonService.getPersons(inputStream);
            for (int i=0;i<persons.size();i++){
                Person person = persons.get(i);
                int image = img[i];
                Bitmap bitmap= BitmapFactory.decodeResource(c.getResources(),image);
                ByteArrayOutputStream baos=new ByteArrayOutputStream();
                //设置位图的压缩格式，质量为100%，并放入字节数组输出流中
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
                //将字节数组输出流转化为字节数组byte[]
                byte[] imagedata1=baos.toByteArray();
                String product_name = person.getName();
                String price = person.getPrice();
                String detail = person.getDetail();
                Integer id_ = person.getId()-1;
                int shop = R.mipmap.logo;
                String sql = "insert into "+TABLE_NAME+"(class_name,image,product_name,price,shop,detail) " +
                        "values(?,?,?,?,?,?)";
                sqLiteDatabase.execSQL(sql,new Object[]{class_name[id_],imagedata1,product_name,price,shop,detail});
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase,int i,int il){
    }

    public void insert2DB(String class_name,byte[] image, String product_name, String price, int shop_logo, String detail){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("class_name",class_name);
        cv.put("image",image);
        cv.put("product_name",product_name);
        cv.put("price",price);
        cv.put("shop",shop_logo);
        cv.put("detail",detail);
        db.insert(TABLE_NAME,null,cv);
        db.close();
    }
    //更新商品库存量
    public void update2DB(String Clause,int value, String id){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(Clause,value);
        String whereClause="_id=?";
        String[] whereArgs = {id };
        db.update(TABLE_NAME,cv,whereClause,whereArgs);
        db.close();
    }
    //删除库存为0的商品
    public void delete2DB(String args){
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause="_id=?";
        String[] whereArgs={args};
        db.delete(TABLE_NAME,whereClause,whereArgs);
        db.close();
    }//*/
}
