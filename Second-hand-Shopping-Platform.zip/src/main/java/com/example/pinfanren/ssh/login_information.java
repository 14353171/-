package com.example.pinfanren.ssh;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Administrator on 2016/12/8 0008.
 */
public class login_information extends SQLiteOpenHelper {
    private static final String NAME = "COUNT";
    private static final String TABLE_NAME = "Contacts";
    private static final int VERSION = 1;

    public login_information(Context context){
        super(context,NAME,null,VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase){
        String CREATE_TABLE = "CREATE TABLE if not exists " + TABLE_NAME
                +" (_id INTEGER PRIMARY KEY,username TEXT,password TEXT)";
        sqLiteDatabase.execSQL(CREATE_TABLE);
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1){}

    public void insert_information(String username, String password){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("password", password);
        db.insert(TABLE_NAME,null,cv);
        db.close();
    }
    public Cursor query_information(){
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME,
                new String[]{"username","password"},
                null,null,null,null,null);
        return cursor;
    }
}
