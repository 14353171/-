package com.example.pinfanren.ssh;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.LinkedHashMap;
import java.util.Map;

public class DetailActivity extends AppCompatActivity {
    private static final String TABLE_NAME = "barn";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goods_detail);

        ImageView product_image = (ImageView) findViewById(R.id.goods_image);
        TextView price = (TextView) findViewById(R.id.price);
        TextView name = (TextView) findViewById(R.id.name);
        TextView detail = (TextView) findViewById(R.id.detial);
        Button button_buy = (Button) findViewById(R.id.button_buy);
        ImageView button_back = (ImageView) findViewById(R.id.button_back);
        button_back.getBackground().setAlpha(130);

        Bundle bundle1 = this.getIntent().getExtras();
        String hh=bundle1.getString("_id");
        // int product_id = bundle1.getInt("_id");
        final int product_id = Integer.parseInt(hh)-1;
        SQLiteDatabase db = MainMenuActivity.myDB.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME,
                new String[]{"class_name","image","product_name","price","shop","detail"},
                null,null,null,null,null);
        cursor.moveToPosition(product_id);
        byte[] imagequery = null;
        imagequery = cursor.getBlob(cursor.getColumnIndex("image"));
        final Bitmap imageBitmap=BitmapFactory.decodeByteArray(imagequery, 0, imagequery.length);
        product_image.setImageBitmap(imageBitmap);
        final String product_name=cursor.getString(cursor.getColumnIndex("product_name"));
        final String product_price=cursor.getString(cursor.getColumnIndex("price"));
        final String product_detail=cursor.getString(cursor.getColumnIndex("detail"));
        name.setText(product_name);
        price.setText(product_price);
        detail.setText(product_detail);
        cursor.close();
        button_buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("product_name",product_name);
                bundle.putString("product_price",product_price);
                bundle.putString("product_detail",product_detail);
                Intent intent = new Intent(DetailActivity.this,Confirm_PayActivity.class);
                intent.putExtras(bundle);
                intent.putExtra("bitmap",imageBitmap);
                startActivity(intent);
            }
        });
        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DetailActivity.this,MainMenuActivity.class);
                startActivity(intent);
            }
        });
    }
}
