package com.example.pinfanren.ssh;

public class Person {
	private Integer id;
	private String name;
	private String price;
	private String detail;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public String getDetail() {
		return detail;
	}

	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", price=" + price + ", detail="+detail+"]";
	}
	public Person(Integer id, String name, String price, String detail) {
		this.id = id;
		this.name = name;
		this.price = price;
		this.detail=detail;
	}	
	public Person() {	
		
	}	
}
