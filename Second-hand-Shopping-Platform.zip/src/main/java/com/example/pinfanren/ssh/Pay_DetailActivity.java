package com.example.pinfanren.ssh;

/**
 * Created by pinfanren on 2016/12/10.
 */

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.preference.DialogPreference;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class Pay_DetailActivity extends AppCompatActivity {
    private TextView receiver, telephone, address, postcode, trade_name, type,
            size_and_color, seller_telephone;
    private Button back, cancel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_layout);

        receiver = (TextView) findViewById(R.id.receiver);
        telephone = (TextView) findViewById(R.id.telephone);
        address = (TextView) findViewById(R.id.address);
        postcode = (TextView) findViewById(R.id.postcode);
        trade_name = (TextView) findViewById(R.id.trade_name);
        type = (TextView) findViewById(R.id.type);
        size_and_color = (TextView) findViewById(R.id.size_and_color);
        seller_telephone = (TextView) findViewById(R.id.seller_telephone);
        back = (Button) findViewById(R.id.back);
        cancel = (Button) findViewById(R.id.cancel);

        Bundle bundle = this.getIntent().getExtras();
        receiver.setText("收件人："+bundle.getString("name"));
        telephone.setText("联系电话："+bundle.getString("phone"));
        address.setText("地址："+bundle.getString("address"));
        postcode.setText("邮政编码："+bundle.getString("postcode"));
        trade_name.setText("商品名称："+bundle.getString("product_name"));
        type.setText("商品类型："+bundle.getString("product_detail"));
        size_and_color.setText("价格："+bundle.getString
                ("product_price"));
        seller_telephone.setText("卖家联系方式："+"123456");

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(Pay_DetailActivity.this,MainMenuActivity.class);
                startActivity(intent);
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder
                        (Pay_DetailActivity.this);
                builder.setMessage("确定取消订单？");
                builder.setTitle("取消订单");
                builder.setPositiveButton("确定", new
                        DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent();
                                intent.setClass
                                        (Pay_DetailActivity.this,Pay_CancelActivity.class);
                                startActivity(intent);
                            }
                        });
                builder.setNegativeButton("取消", new
                        DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                builder.show();
            }
        });

    }
}
