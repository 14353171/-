package com.example.pinfanren.ssh;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

import cn.smssdk.EventHandler;
import cn.smssdk.SMSSDK;
import cn.smssdk.gui.RegisterPage;

public class Log_in_Activity extends AppCompatActivity {
    private Button Register,log_in;
    private EditText username,password;
    login_information DB = new login_information(this);
    static int flag,temp;
    private static String APPKEY = "19c1f3a406900";
    private static String APPSECRET = "7cd5bf123f7225628c77eb8ce185b4dd";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        Register = (Button) findViewById(R.id.login_register);
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent_register = new Intent(Log_in_Activity.this,registered_Activity.class);
                startActivity(intent_register);
            }
        });
        Button phone = (Button)findViewById(R.id.phone_register);
        SMSSDK.initSDK(this, APPKEY, APPSECRET);//初始化SDK
        phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //打开注册页面
                RegisterPage registerPage = new RegisterPage();
                registerPage.setRegisterCallback(new EventHandler() {
                    public void afterEvent(int event, int result, Object data) {
                        // 解析注册结果
                        if (result == SMSSDK.RESULT_COMPLETE) {
                            @SuppressWarnings("unchecked")
                            Intent intent = new Intent(Log_in_Activity.this, MainMenuActivity.class);
                            startActivity(intent);
                        }
                    }
                });
                registerPage.show(Log_in_Activity.this);
            }
        });
        log_in = (Button) findViewById(R.id.log_in);
        username = (EditText) findViewById(R.id.login_username_input);
        password = (EditText) findViewById(R.id.login_password_input);
        final SharedPreferences sp = getSharedPreferences("MY_PREFERENCE", MODE_PRIVATE);
        final String pass = sp.getString("password","");
        log_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor query = DB.query_information();

                if (username.getText().toString().equals("") || password.getText().toString().equals("")){
                    Toast.makeText(Log_in_Activity.this, "用户名和密码不能为空！", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (query.getCount() == 0) {
                        Toast.makeText(Log_in_Activity.this, "用户名不存在！", Toast.LENGTH_SHORT).show();
                    } else {
                        temp = 0;
                        flag = 0;
                        while (query.moveToNext()) {
                            int num_name = query.getColumnIndex("username");
                            String name = query.getString(num_name);
                            int num_pass = query.getColumnIndex("password");
                            String pass = query.getString(num_pass);
                            if (!username.getText().toString().equals(name)) {
                                flag = 1;
                            } else {
                                flag = 0;
                                if (!password.getText().toString().equals(pass)) {
                                    temp = 1;
                                    break;
                                } else {
                                    flag = 0;
                                    temp = 0;
                                    break;
                                }
                            }

                        }
                        if (flag > 0) {
                            Toast.makeText(Log_in_Activity.this, "用户名不存在！", Toast.LENGTH_SHORT).show();
                        } else {
                            if (temp > 0) {
                                Toast.makeText(Log_in_Activity.this, "密码不正确！", Toast.LENGTH_SHORT).show();
                            } else {
                                Intent intent = new Intent(Log_in_Activity.this, MainMenuActivity.class);
                                startActivity(intent);
                            }
                        }
                    }
                }
            }
        });
    }
}
