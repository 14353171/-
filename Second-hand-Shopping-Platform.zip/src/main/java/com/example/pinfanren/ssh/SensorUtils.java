package com.example.pinfanren.ssh;

/**
 * Created by pinfanren on 2016/12/8.
 */
import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.widget.Toast;

public class SensorUtils {

    public static final int TYPE_LOCATION_CHANGE = 3;

    private static SensorUtils mInstance;

    public static synchronized SensorUtils getInstance() {
        if (mInstance == null) {
            mInstance = new SensorUtils();
        }
        return mInstance;
    }
    private SensorUtils() {
        mSensorManager = (SensorManager) BaseApplication.getContext()
                .getSystemService(Context.SENSOR_SERVICE);
        mLocationManager = (LocationManager) BaseApplication.getContext()
                .getSystemService(Context.LOCATION_SERVICE);

    }

    private SensorManager mSensorManager;

    private LocationManager mLocationManager;
    private Location mCurrentLocation;

    private OnSensorUpdateListener mOnSensorUpdateListener;

    private LocationListener mGPSListener = new LocationListener() {

        private boolean networkIsRemove = false;

        @Override
        public void onLocationChanged(Location location) {
            boolean flag = isBetterLocation(location,
                    mCurrentLocation);
            if (flag) {
                mCurrentLocation = location;
                if (mOnSensorUpdateListener != null) {
                    mOnSensorUpdateListener.onSensorUpdate(TYPE_LOCATION_CHANGE,
                            new float[]{(float) mCurrentLocation.getLongitude(),
                                    (float) mCurrentLocation.getLatitude(),
                                    (float) mCurrentLocation.getAltitude()});
                }
                //makeToast("Location Update from GPS");
            }

            if (location != null && !networkIsRemove) {
                if (ActivityCompat.checkSelfPermission(BaseApplication.getContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(BaseApplication.getContext(), Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                mLocationManager.removeUpdates(mNetworkListener);
                networkIsRemove = true;
            }
        }
        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            if (LocationProvider.OUT_OF_SERVICE == status) {
               // makeToast("Lost GPS, change to network");
                if (ActivityCompat.checkSelfPermission(BaseApplication.getContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(BaseApplication.getContext(), Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
                    return;
                }

                if (mLocationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    mLocationManager.requestLocationUpdates(
                            LocationManager.NETWORK_PROVIDER, 0, 0, mNetworkListener);
                    networkIsRemove = false;
                }
            }
        }

        @Override
        public void onProviderEnabled(String provider) {
           // makeToast("Enable GPS provider");
        }

        @Override
        public void onProviderDisabled(String provider) {
           // makeToast("Disable GPS provider");
        }
    };

    private LocationListener mNetworkListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            mCurrentLocation = location;
            if (mOnSensorUpdateListener != null) {
                mOnSensorUpdateListener.onSensorUpdate(TYPE_LOCATION_CHANGE,
                        new float[]{(float) mCurrentLocation.getLongitude(),
                                (float) mCurrentLocation.getLatitude(),
                                (float) mCurrentLocation.getAltitude()});
            }
            //makeToast("Location Update from network");
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String provider) {
           // makeToast("Enable network provider");
        }

        @Override
        public void onProviderDisabled(String provider) {
            //makeToast("Disable network provider");
        }
    };

    public void setOnSensorUpdateListener(OnSensorUpdateListener onSensorUpdateListener) {
        this.mOnSensorUpdateListener = onSensorUpdateListener;
    }

    public void removeOnSensorUpdateListener(OnSensorUpdateListener onSensorUpdateListener) {
        if (onSensorUpdateListener == this.mOnSensorUpdateListener) {
            this.mOnSensorUpdateListener = null;
        }
    }

    public void registerSensor() throws SecurityException {

        if (mLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, mGPSListener);
        }
        if (mLocationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
            mLocationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, mNetworkListener);
        }
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setAltitudeRequired(false);
        criteria.setBearingRequired(false);
        criteria.setCostAllowed(true);
        String provider = mLocationManager.getBestProvider(criteria, true);
        mLocationManager.getLastKnownLocation(provider);
        mCurrentLocation = mLocationManager.getLastKnownLocation(provider);
    }
    public Location getCurrentLocation() {
        return mCurrentLocation;
    }


    public interface OnSensorUpdateListener {
        void onSensorUpdate(int type, float[] values);
    }

    private static final int TWO_MINUTES = 1000 * 60 * 2;

    protected boolean isBetterLocation(Location location, Location currentBestLocation) {
        if (currentBestLocation == null) {
            // A new location is always better than no location
            return true;
        }

        // Check whether the new location fix is newer or older
        long timeDelta = location.getTime() - currentBestLocation.getTime();
        boolean isSignificantlyNewer = timeDelta > TWO_MINUTES;
        boolean isSignificantlyOlder = timeDelta < -TWO_MINUTES;
        boolean isNewer = timeDelta > 0;

        // If it's been more than two minutes since the current location, use the new location
        // because the user has likely moved
        if (isSignificantlyNewer) {
            return true;
            // If the new location is more than two minutes older, it must be worse
        } else if (isSignificantlyOlder) {
            return false;
        }

        // Check whether the new location fix is more or less accurate
        int accuracyDelta = (int) (location.getAccuracy() - currentBestLocation.getAccuracy());
        boolean isLessAccurate = accuracyDelta > 0;
        boolean isMoreAccurate = accuracyDelta < 0;
        boolean isSignificantlyLessAccurate = accuracyDelta > 200;

        // Check if the old and new location are from the same provider
        boolean isFromSameProvider = isSameProvider(location.getProvider(),
                currentBestLocation.getProvider());

        // Determine location quality using a combination of timeliness and accuracy
        if (isMoreAccurate) {
            return true;
        } else if (isNewer && !isLessAccurate) {
            return true;
        } else if (isNewer && !isSignificantlyLessAccurate && isFromSameProvider) {
            return true;
        }
        return false;
    }

    /**
     * Checks whether two providers are the same
     */
    private boolean isSameProvider(String provider1, String provider2) {
        if (provider1 == null) {
            return provider2 == null;
        }
        return provider1.equals(provider2);
    }

}
