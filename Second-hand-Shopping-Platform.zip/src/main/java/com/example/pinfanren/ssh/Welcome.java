package com.example.pinfanren.ssh;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by pinfanren on 2016/12/1.
 */

public class Welcome extends AppCompatActivity {
    private Timer timer = new Timer();
    @Override
    public void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.welcome);
        final Button jump=(Button)findViewById(R.id.jump);
        final Intent it = new Intent(this, Log_in_Activity.class); //转向的Activity
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                    startActivity(it); //执行
            }
        };
        timer.schedule(task, 1000*3); //3秒后
        jump.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(it); //执行
                timer.cancel();//取消定时器计时
            }
        });
    }
}
