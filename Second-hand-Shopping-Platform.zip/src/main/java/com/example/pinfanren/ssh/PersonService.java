package com.example.pinfanren.ssh;

import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlSerializer;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class PersonService {
	public static List<Person> getPersons(InputStream xml) throws Exception {		
		List<Person> persons = null;
		Person person = null;
		XmlPullParser pullParser = Xml.newPullParser();
		pullParser.setInput(xml, "UTF-8");
		int event = pullParser.getEventType();
		while (event != XmlPullParser.END_DOCUMENT){
			switch (event) {
			case XmlPullParser.START_DOCUMENT:
				persons = new ArrayList<Person>();
				break;	
			case XmlPullParser.START_TAG:	
				if ("person".equals(pullParser.getName())){
					int id = Integer.valueOf(pullParser.getAttributeValue(0));
					person = new Person();
					person.setId(id);
				}
				if ("name".equals(pullParser.getName())){
					String name = pullParser.nextText();
					person.setName(name);
				}								
				if ("price".equals(pullParser.getName())){
					String price= pullParser.nextText();
					person.setPrice(price);
				}
				if("detail".equals(pullParser.getName())){
					String detail=pullParser.nextText();
					person.setDetail(detail);
				}
				break;
			case XmlPullParser.END_TAG:
				if ("person".equals(pullParser.getName())){
					persons.add(person);
				}
				break;
			}
			event = pullParser.next();
		}
		return persons;
	}
}
