package com.example.pinfanren.ssh;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

/**
 * Created by pinfanren on 2016/11/30.
 */

public class MainMenuActivity extends AppCompatActivity {

    private ListView listView;
    private RecyclerView recyclerView;
    private EditText search_text;
    private ImageButton search;
    private TextView mLocationTextView;
    private SensorUtils mSensorUtils;
    private boolean isProcessingShake = false;
    public static MyDB myDB=null;
    private SQLiteDatabase db;
    private List<Map<String, Object>> members = new ArrayList<>();
    private ArrayList<Integer> class_list = new ArrayList<>();
    private static final String TABLE_NAME = "barn";
    private Cursor cursor;
    private String[]class_name={"clothes","bag","book","electronic","all"};
    private SimpleAdapter simpleAdapter=null;
    //public static Context context;
    @Override
    public void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.listview);
        recyclerView = (RecyclerView) findViewById(R.id.recycle);
        search_text = (EditText) findViewById(R.id.search_text);
        search = (ImageButton) findViewById(R.id.search);
        mLocationTextView = (TextView)findViewById(R.id.location);
        mSensorUtils = SensorUtils.getInstance();
        mSensorUtils.setOnSensorUpdateListener(mOnSensorUpdateListener);
        updateLocation(mSensorUtils.getCurrentLocation());
        members.clear();
        myDB = new MyDB(this);
        db = myDB.getReadableDatabase();
        cursor = db.rawQuery("select * from " + TABLE_NAME, null);
        updateListView();
        simpleAdapter = new SimpleAdapter(this, members, R.layout.item,
                new String[]{"class_name", "_id", "image", "product_name", "price"},
                new int[]{R.id.class_name, R.id._id, R.id.image, R.id.product_name, R.id.price});
        /*实现ViewBinder()这个接口*/
        simpleAdapter.setViewBinder(new SimpleAdapter.ViewBinder() {
            @Override
            public boolean setViewValue(View view, Object data, String textRepresentation) {
                if(view instanceof ImageView && data instanceof Bitmap){
                    ImageView i = (ImageView)view;
                    i.setImageBitmap((Bitmap) data);
                    return true;
                }
                return false;
            }
        });
        listView.setAdapter(simpleAdapter);
        cursor.close();
        db.close();
        int[] hh = {R.mipmap.cloth, R.mipmap.bag, R.mipmap.book, R.mipmap.electronic,R.mipmap.home};
        class_list.clear();
        for (int i = 0; i < 5; i++) {
            class_list.add(hh[i]);

        }
        LinearLayoutManager layoutManager = new LinearLayoutManager(MainMenuActivity.this);
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        recyclerView.setLayoutManager(layoutManager);
        ClassAdapter adapter = new ClassAdapter(MainMenuActivity.this,class_list);
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(new ClassAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                if(position<4) {
                    SQLiteDatabase db = myDB.getReadableDatabase();
                    cursor = db.rawQuery("select * from " + TABLE_NAME + " where class_name=?", new String[]{class_name[position]});
                    updateListView();
                    simpleAdapter.notifyDataSetChanged();
                    cursor.close();
                    db.close();
                }
                else{
                    SQLiteDatabase db = myDB.getReadableDatabase();
                    cursor = db.rawQuery("select * from " + TABLE_NAME, null);
                    updateListView();
                    simpleAdapter.notifyDataSetChanged();
                    cursor.close();
                    db.close();
                }
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String _id=members.get(position).get("_id").toString();
                Intent myIntent = new Intent(MainMenuActivity.this,DetailActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("_id",_id);
                myIntent.putExtras(bundle);
                startActivityForResult(myIntent,0);
            }
        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String search_context = search_text.getText().toString();
                String sql  = "select * from " + TABLE_NAME +
                        " where class_name like ? or product_name like ? or price like ? or shop like ? or detail like ? ";
                String [] selectionArgs  = new String[]{"%" + search_context + "%",
                        "%" + search_context + "%",
                        "%" + search_context + "%",
                        "%" + search_context + "%",
                        "%" + search_context + "%"};
                SQLiteDatabase db = myDB.getReadableDatabase();
                cursor = db.rawQuery(sql, selectionArgs);
                updateListView();
                simpleAdapter.notifyDataSetChanged();
                cursor.close();
                db.close();
            }
        });

    }
    private SensorUtils.OnSensorUpdateListener mOnSensorUpdateListener = new SensorUtils.OnSensorUpdateListener() {
        @Override
        public void onSensorUpdate(int type, float[] values) {
            switch (type) {
                case SensorUtils.TYPE_LOCATION_CHANGE:
                    updateLocation(mSensorUtils.getCurrentLocation());
                    break;
                default:
                    break;
            }
        }
    };
    @Override
    protected void onResume() {
        super.onResume();
        mSensorUtils.registerSensor();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private void updateLocation(Location location) {
        if (location == null) {
            mLocationTextView.setText("定位失败");
        } else {
            new MainMenuActivity.GeoDecoder().execute(location);
        }
    }
    private class GeoDecoder extends AsyncTask<Location, Integer, String> {
        @Override
        protected String doInBackground(Location... params) {
            Location param = params[0];
            try {
                String result = sendHttpRequest(String.format(getString(R.string.coor_change),
                        param.getLongitude(), param.getLatitude(), getString(R.string.server_ak)));
                JSONObject jObject = new JSONObject(result);
                JSONArray jsonArray = jObject.getJSONArray("result");
                JSONObject locObject = jsonArray.getJSONObject(0);
                double x = locObject.getDouble("x");
                double y = locObject.getDouble("y");
                String decode = sendHttpRequest(String.format(getString(R.string.geo_decode),
                        y, x, getString(R.string.server_ak)));
                JSONObject geoObject = new JSONObject(decode);
                return geoObject.getString("formatted_address");
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            }
            return "Error";
        }

        @Override
        protected void onPostExecute(String s) {
            String str=s.substring(0,s.indexOf("市")+1);
            mLocationTextView.setText(str);
        }
        private String sendHttpRequest(String request) throws IOException {
            URL url = new URL(request);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            InputStream is = connection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String response = "";
            String readLine;
            while ((readLine = br.readLine()) != null) {
                response = response + readLine;
            }
            is.close();
            br.close();
            connection.disconnect();
            return response;
        }
    }
    private void updateListView(){
        members.clear();
        for(cursor.moveToFirst();!cursor.isAfterLast();cursor.moveToNext()){
            Map<String,Object>temp = new LinkedHashMap<>();
            String class_name = cursor.getString(cursor.getColumnIndex("class_name"));
            String id = cursor.getString(cursor.getColumnIndex("_id"));
            byte[] image = cursor.getBlob(cursor.getColumnIndex("image"));
            Bitmap imageBitmap=BitmapFactory.decodeByteArray(image, 0, image.length);
            String product_name = cursor.getString(cursor.getColumnIndex("product_name"));
            String price = cursor.getString(cursor.getColumnIndex("price"));
            int shop =  cursor.getInt(cursor.getColumnIndex("shop"));
            temp.put("class_name",class_name);
            temp.put("_id",id);
            temp.put("image",imageBitmap);
            temp.put("product_name",product_name);
            temp.put("price","¥"+price);
            temp.put("shop",shop);
            members.add(temp);
        }
    }
}
